#include <stdio.h> //Estandar
#include <sys/socket.h> //Sockets
#include <stdlib.h> //Exit function
#include <netinet/in.h> //Address of IP protcol
#include <sys/types.h> //Bind
#include <string.h> //memcpy
#include <arpa/inet.h> //inet_addr

struct sockaddr_in addrSolicitud ( 
	unsigned char ip [], 
	int port
);

struct sockaddr_in addrSolicitud ( unsigned char ip [], int port) {
	struct sockaddr_in addr_remote;
	addr_remote.sin_family= AF_INET;
	addr_remote.sin_port= htons(port);
	addr_remote.sin_addr.s_addr=inet_addr(ip);
	return addr_remote;
}

void newDir ( int * socket_local) {
	struct sockaddr_in addr_local;
	int bind_local;
	addr_local.sin_family = AF_INET;
	addr_local.sin_port = htons( 0 );
	addr_local.sin_addr.s_addr = INADDR_ANY;
	bind_local = bind( *socket_local, ( struct sockaddr * ) &addr_local, sizeof( addr_local ) );
	if ( bind_local == -1 ) {
		perror( "Estado de bind_local" );
		exit( 0 );
	} 
	else perror( "Estado de bind_local" ); 
}

void encabezadoDefault ( unsigned char * paq_solicitud ) {
	unsigned char id_transaccion[2] = {0x00, 0x01};
	unsigned char indicadores[2] = {0x01, 0x00};
	unsigned char contador_repeticiones[2] = {0x00, 0x01};
	unsigned char contador_respuesta[2] = {0x00, 0x00};
	unsigned char contador_autoridades[2] = {0x00, 0x00};
	unsigned char contador_adicional[2] = {0x00, 0x00};
	memcpy( paq_solicitud + 0, id_transaccion, 2 );
	memcpy( paq_solicitud + 2, indicadores, 2 );
	memcpy( paq_solicitud + 4, contador_repeticiones, 2 );
	memcpy( paq_solicitud + 6, contador_respuesta, 2 );
	memcpy( paq_solicitud + 8, contador_autoridades, 2 );
	memcpy( paq_solicitud + 10, contador_adicional, 2 );
}

int newSocket () {
	int socket_local;
	socket_local = socket( AF_INET, SOCK_DGRAM, 0 );
	if ( socket_local == -1 ) {
		perror( "\nEstado de socket_local" );
		exit( 0 );
	} else {
		perror( "\nEstado de socket_local" );
		newDir( &socket_local );
		return socket_local;
	}
}

void sendSolicitud ( int socket_local, unsigned char paq_solicitud[],
	int tam_solicitud, struct sockaddr_in addr_remote ) {
	tam_solicitud = sendto( socket_local, paq_solicitud, tam_solicitud, 0, (struct sockaddr *)&addr_remote, sizeof( addr_remote ) );
	if( tam_solicitud == -1 ) {
		perror( "Estado del envio" );
		exit( 0 );
	} else perror( "\nEstado del envio" );
}

int estrucSolicitud ( unsigned char * paq_solicitud, unsigned char name_search[] ) {
	int i=0, j=0;
	encabezadoDefault( paq_solicitud );
	int tam_search = strlen(name_search);
	unsigned char name_converted[tam_search];
	for(i; i < tam_search; i++) {
		if(name_search[i] == '.' || name_search[i] == '\n') {
			name_converted[j] = (short)(i-j);
			for(j = j+1; j<i+1; j++) name_converted[j] = name_search[j-1];
			if(name_search[i] == '\n') name_converted[j] = 0x00;
			else j = i+1;
		}
	}
	tam_search = tam_search + 1;
	unsigned char tipo_peticion[2] = { 0x00, 0x01 };
	unsigned char clase_peticion[2] = { 0x00, 0x01 };
	memcpy( paq_solicitud + 12, name_converted, tam_search );
	memcpy( paq_solicitud + 12 + tam_search, tipo_peticion, 2 );
	memcpy( paq_solicitud + 14 + tam_search, clase_peticion, 2 );
	return ( 16 + tam_search );
}
