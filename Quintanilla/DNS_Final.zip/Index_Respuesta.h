#include <stdio.h> //Estandar
#include <stdlib.h> //Exit
#include <sys/time.h> //time
#include <netinet/in.h> //Address of IP protcol

int tipo;

int readQueri ( unsigned char paq_respuesta[] ) {
	int i, position=12;
	printf("\n--> Queri\n");
	printf("  --> ");
	do {
		for( i=1; i <= paq_respuesta [position]; i++) printf("%c", paq_respuesta [position+i]);
		position = position + i;
		if( paq_respuesta [position] == 0x00) {
			printf(":  ");
			position = position + i;
			break;
		}
		else printf(".");
	} while (1);
	if( paq_respuesta [position+1] == 0x01) printf("tipo: RegistroHost  ");
	else if( paq_respuesta [position+1] == 0x02) printf("tipo: A  ");
	else if( paq_respuesta [position+1] == 0x05) printf("tipo: CNAME  ");
	printf("clase: IN(0X0001)\n");
	return position + 2;
}

int leerNom ( unsigned char paq_respuesta[], int position) {
	int apuntador, i;
	do {
		if( paq_respuesta[position] == 0xC0 ) {
			apuntador = paq_respuesta[position + 1];
			do {
				for( i=1; i <= paq_respuesta [apuntador]; i++ ) {
					printf("%c", paq_respuesta [apuntador + i]);
				}
				apuntador = apuntador + i;
				if( paq_respuesta [apuntador] == 0xC0 ) {
					printf(".");
					leerNom( paq_respuesta, apuntador );
					return position + 2;
					break;
				}
				if( paq_respuesta [apuntador] == 0x00) {
					return position + 2;
					break;
				}
				else printf(".");
			} while (1);
			break;
		}
		else {
			do {
				if( paq_respuesta [position] == 0xC0 ) { break; }
				for( i=1; i <= paq_respuesta [position]; i++ ) printf("%c", paq_respuesta [position + i]);
				position = position + i;
				if( paq_respuesta [position] == 0x00) {
					printf(":  ");
					position = position + i;
					break;
				} else {
					printf(".");
				}
			} while (1);
		}
	} while (1);
}
int leerIP ( unsigned char paq_respuesta[], int position) {
   printf("%i.%i.",paq_respuesta[position], paq_respuesta[position+1]);
   printf("%i.%i",paq_respuesta[position+2], paq_respuesta[position+3]);
   return position+4;
}

int tipeClass( unsigned char paq_respuesta[], int position ) {
   tipo = paq_respuesta [position+1];
   if( paq_respuesta [position+1] == 0x01) printf("tipo: RegistroHost  ");
   else if( paq_respuesta [position+1] == 0x02) printf("tipo: A  ");
   else if( paq_respuesta [position+1] == 0x05) printf("tipo: CNAME  ");
   printf("clase: IN  ");
   return position + 4;
}

int readAll( unsigned char paq_respuesta[], int position ) {
	int tam;
	printf("    --> ");
	position = leerNom( paq_respuesta, position);
	printf(":  ");
	position = tipeClass( paq_respuesta, position );
	printf("TTL: %i,  ", (paq_respuesta[position]<<24) | (paq_respuesta[position+1]<<16) | (paq_respuesta[position + 2]<<8) | paq_respuesta[position + 3] );
	tam = htons(((paq_respuesta[position + 4] << 8) &0xFF00) | (paq_respuesta[position + 5] & 0xFF));
	position = position + 6;
	if( tipo == 0x01 ) {
		printf("addr ");
		position = leerIP( paq_respuesta, position );
		printf("\n");
	}
	else if( tipo == 0x02 ) {
		printf("ns ");
		position = leerNom( paq_respuesta, position );
		printf("\n");
	}
	else if( tipo == 0x05 ) {
		printf("cname ");
		position = leerNom( paq_respuesta, position );
		printf("\n");
	}
	return position;
}

int waitReplay (int socket_local, unsigned char * paq_respuesta, struct sockaddr_in addr_remote) {
	struct timeval start, end;
	int tam_respuesta;
	int timeEspera = 1000;
	long mtime=0, seconds, useconds;
	int lrecv = sizeof(addr_remote);
	gettimeofday(&start, NULL);
	while (mtime<timeEspera) {
		tam_respuesta = recvfrom(socket_local, paq_respuesta, 512, MSG_DONTWAIT, (struct sockaddr *)&addr_remote, &lrecv);
		if(tam_respuesta==-1) {} ///////////
		else {
			printf("Estado de la respuesta: Success\n");
			return tam_respuesta;
		}
		gettimeofday(&end, NULL);
		seconds = end.tv_sec -start.tv_sec;
		useconds = end.tv_usec -start.tv_usec;
		mtime = ((seconds) * 1000 + useconds/1000.0) + 0.5;
	}
	perror( "Estado de la respuesta" );
	return tam_respuesta;
}

int readHeader ( unsigned char paq_respuesta[] ) {
	printf( "  --> ID: %i\n", htons( ( ( paq_respuesta[1] << 8 ) &0xFF00 ) | ( paq_respuesta[0] & 0xFF ) ) );
	printf( "  --> Flags: %.2X %.2X\n", paq_respuesta[2], paq_respuesta[3] );
	if(1) { 
		if( (paq_respuesta[2] & 0x04) == 0x04 ) printf("     --> Autoridad: Si\n"); 
		else printf("     --> Autoridad: No\n");
	}
	if(1) { 
		if( (paq_respuesta[2] & 0x02) == 0x02 ) printf("     --> Trunco: Si\n"); 
		else printf("     --> Trunco: No\n"); 
	}
	if(1) { 
		if( (paq_respuesta[2] & 0x01) == 0x01 ) printf("     --> Recursion: Activa\n"); 
		else printf("     --> Recursion: Desactivada\n"); 
	}
	if(1) { 
		if( (paq_respuesta[3] & 0x80) == 0x80 ) printf("     --> Recursion Disponible: Si\n"); 
		else printf("     --> Recursion Disponible: No\n"); 
	}
	if(1) { 
		if( (paq_respuesta[3] & 0x05 ) == 0x05 || (paq_respuesta[3] & 0x03) == 0x03) {
			printf("     --> Codigo de Retorno: Error\n"); 
			exit(0);
		} 
		else printf("     --> Codigo de Retorno: Success\n"); 
		printf("  --> Questions: %i\n", htons(((paq_respuesta[5] << 8) &0xFF00) | (paq_respuesta[4] & 0xFF)));
		printf("  --> Answer RRs: %i\n", htons(((paq_respuesta[7] << 8) &0xFF00) | (paq_respuesta[6] & 0xFF)));
		printf("  --> Authority RRs: %i\n", htons(((paq_respuesta[9] << 8) &0xFF00) | (paq_respuesta[8] & 0xFF)));
		printf("  --> Additional RRs: %i\n", htons(((paq_respuesta[11] << 8) &0xFF00) | (paq_respuesta[10] & 0xFF)));
	return readQueri( paq_respuesta );
}

void readRR ( unsigned char paq_respuesta[], int position ) {
	int i;
	int answer = htons(((paq_respuesta[7] << 8) &0xFF00) | (paq_respuesta[6] & 0xFF));
	int authority = htons(((paq_respuesta[9] << 8) &0xFF00) | (paq_respuesta[8] & 0xFF));
	int additional = htons(((paq_respuesta[11] << 8) &0xFF00) | (paq_respuesta[10] & 0xFF));
	if( answer ) { //Answer
		printf("  --> Answer:\n");
		for(i=0; i < answer; i++) position = readAll( paq_respuesta, position );
	}
	if( authority ) { //Authority
		printf("  --> Authority:\n");
		for(i=0; i < authority; i++) position = readAll( paq_respuesta, position );
	}
	if( additional ) { //Additional
		printf("  --> Additional:\n");
		for(i=0; i < authority; i++) position = readAll( paq_respuesta, position );
	}
}
